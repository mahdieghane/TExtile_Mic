import numpy as np    
import socket
import threading
import time
import joblib
import json
import os
from device import Device
from device1 import Device1
from device2 import Device2
from device3 import Device3
from device4 import Device4

from streaming_server import Server
from dsp_utils import DSPUtils

SAMPLE_DATA = 0
SAMPLE_FFT = 1
DATA_COLLECTION_FOLDER = "./demo_data/"
activity_list = ["Writing", "Chopping","Knocking","Tapping", "Clapping" , "Washing hands", "Grating",  "Cleaning", "Drinking", "Chewing","Coughing","Sneezing","Snoring", "Speaking", "Walking", "Standing Up", "Fall detection", "Jumping", "Crunch", "Squat",  "Running", "Noise"]


def collect_data(device,device1,device2,device3,device4, streaming_server):
    thing_name = input("Item Name :\n")
    #thing_name = "cuttingboard"
    if not os.path.exists(DATA_COLLECTION_FOLDER+thing_name + "/"):
        os.makedirs(DATA_COLLECTION_FOLDER+thing_name + "/")
    user_name = input("Participant Name :\n")
    #user_name = "p0"
    if not os.path.exists(DATA_COLLECTION_FOLDER+thing_name + "/" +user_name + "/"):
        os.makedirs(DATA_COLLECTION_FOLDER+thing_name + "/" + user_name + "/")

    if not os.path.exists(DATA_COLLECTION_FOLDER+thing_name + 'device1'+ "/"):
        os.makedirs(DATA_COLLECTION_FOLDER+thing_name + 'device1'+"/")
    user_name = input("Participant Name :\n")
    #user_name = "p0"
    if not os.path.exists(DATA_COLLECTION_FOLDER+thing_name + 'device1'+ "/" +user_name + 'device1'+"/"):
        os.makedirs(DATA_COLLECTION_FOLDER+thing_name + 'device1'+ "/" + user_name + 'device1'+"/")


    if not os.path.exists(DATA_COLLECTION_FOLDER+thing_name + 'device2'+ "/"):
        os.makedirs(DATA_COLLECTION_FOLDER+thing_name + 'device2'+"/")
    user_name = input("Participant Name :\n")
    #user_name = "p0"
    if not os.path.exists(DATA_COLLECTION_FOLDER+thing_name+ 'device2' + "/" +user_name + 'device2'+"/"):
        os.makedirs(DATA_COLLECTION_FOLDER+thing_name+ 'device2' + "/" + user_name + 'device2'+"/")

    if not os.path.exists(DATA_COLLECTION_FOLDER+thing_name + 'device3'+ "/"):
        os.makedirs(DATA_COLLECTION_FOLDER+thing_name + 'device3'+"/")
    user_name = input("Participant Name :\n")
    #user_name = "p0"
    if not os.path.exists(DATA_COLLECTION_FOLDER+thing_name+ 'device3' + "/" +user_name + 'device3'+"/"):
        os.makedirs(DATA_COLLECTION_FOLDER+thing_name+ 'device3' + "/" + user_name + 'device3'+"/")


    if not os.path.exists(DATA_COLLECTION_FOLDER+thing_name + 'device4'+ "/"):
        os.makedirs(DATA_COLLECTION_FOLDER+thing_name + 'device4'+"/")
    user_name = input("Participant Name :\n")
    #user_name = "p0"
    if not os.path.exists(DATA_COLLECTION_FOLDER+thing_name+ 'device4' + "/" +user_name + 'device4'+"/"):
        os.makedirs(DATA_COLLECTION_FOLDER+thing_name+ 'device4' + "/" + user_name + 'device4'+"/")



    record_data = []
    record_data1 = []
    record_data2 = []
    record_data3 = []
    record_data4 = []

    is_recording = False
    record_starting_time = 0,

    overwrite = False
    calibrated = False
    activity_index = 0
    
    background_fft_profile = device.calculate_background_fft_profile()
    background_fft_profile1 = device1.calculate_background_fft_profile()
    background_fft_profile2 = device2.calculate_background_fft_profile()
    background_fft_profile3 = device3.calculate_background_fft_profile()
    background_fft_profile4 = device4.calculate_background_fft_profile()

    #### calibrate

    while True:

        ### get and interpret the command from the client
        cmd = streaming_server.read_client_command()
        if cmd:
            if cmd == 'R':
                is_recording = True
                record_data = []
                start_time = time.time()
            elif cmd == 'S':
                is_recording = False
            elif cmd == 'X':
                print("overwrite the last one")
                overwrite = True
            elif cmd == 'Z':
                background_fft_profile = device.calculate_background_fft_profile()
                background_fft_profile1 = device1.calculate_background_fft_profile()
                background_fft_profile2 = device2.calculate_background_fft_profile()
                background_fft_profile3 = device3.calculate_background_fft_profile()
                background_fft_profile4 = device4.calculate_background_fft_profile()
                print("update background profile")
            else:
                o_index = ord(cmd)-ord('A')
                print(o_index)
                if 0 <= o_index < len(activity_list):
                    activity_index = o_index
                    print("record activity " + activity_list[activity_index]) 

        signal_in_one_window = device.sample()
        signal_in_one_window1 = device1.sample()
        signal_in_one_window2 = device2.sample()
        signal_in_one_window3 = device3.sample()
        signal_in_one_window4 = device4.sample()

        if len(signal_in_one_window) > 0 :
            streaming_server.streaming_signal_in_FFT(signal_in_one_window, background_fft_profile,Device)
            if is_recording:
                record_data.append(signal_in_one_window.tolist())
                if time.time() - start_time > 3:
                     is_recording = False

        if len(signal_in_one_window1) > 0 :
            streaming_server.streaming_signal_in_FFT(signal_in_one_window1, background_fft_profile1,Device1)
            if is_recording:
                record_data1.append(signal_in_one_window1.tolist())
                if time.time() - start_time > 3:
                     is_recording = False


        if len(signal_in_one_window2) > 0 :
            streaming_server.streaming_signal_in_FFT(signal_in_one_window2, background_fft_profile2,Device2)
            if is_recording:
                record_data2.append(signal_in_one_window2.tolist())
                if time.time() - start_time > 3:
                     is_recording = False


        if len(signal_in_one_window3) > 0 :
            streaming_server.streaming_signal_in_FFT(signal_in_one_window3, background_fft_profile3,Device3)
            if is_recording:
                record_data3.append(signal_in_one_window3.tolist())
                if time.time() - start_time > 3:
                     is_recording = False


        if len(signal_in_one_window4) > 0 :
            streaming_server.streaming_signal_in_FFT(signal_in_one_window4, background_fft_profile4,Device4)
            if is_recording:
                record_data4.append(signal_in_one_window4.tolist())
                if time.time() - start_time > 3:
                     is_recording = False




                
        if len(record_data) > 0 and not is_recording:
            
            ## create file if it doesn't exist or 
            ## append data to the file if it exists
            try:
                with open(DATA_COLLECTION_FOLDER + thing_name + "/" + user_name + "/" + activity_list[activity_index]+'.json', "r") as file:
                    listObj = json.load(file)
            except:
                listObj = []
                print("new file")

            ### store the data into the list
            with open(DATA_COLLECTION_FOLDER+thing_name + "/" + user_name + "/"+ activity_list[activity_index]+'.json', "w+") as file:
                print(activity_list[activity_index])
                print(len(listObj))
                if overwrite and len(listObj) > 0:
                    listObj[-1] = {"background": background_fft_profile.tolist(), "record_data":record_data}
                    overwrite = False
                else:
                    listObj.append({"background": background_fft_profile.tolist(), "record_data":record_data})
                json.dump(listObj, file, allow_nan = True)
                print("Record Finish")
            record_data = []



        if len(record_data1) > 0 and not is_recording:
            
            ## create file if it doesn't exist or 
            ## append data to the file if it exists
            try:
                with open(DATA_COLLECTION_FOLDER + thing_name+'device1' + "/" + user_name +'device1'+ "/" + activity_list[activity_index]+'device1'+'.json', "r") as file:
                    listObj = json.load(file)
            except:
                listObj = []
                print("new file")

            ### store the data into the list
            with open(DATA_COLLECTION_FOLDER+thing_name +'device1'+ "/" + user_name +'device1'+ "/"+ activity_list[activity_index]+'device1'+'.json', "w+") as file:
                print(activity_list[activity_index])
                print(len(listObj))
                if overwrite and len(listObj) > 0:
                    listObj[-1] = {"background": background_fft_profile1.tolist(), "record_data":record_data1}
                    overwrite = False
                else:
                    listObj.append({"background": background_fft_profile1.tolist(), "record_data":record_data1})
                json.dump(listObj, file, allow_nan = True)
                print("Record Finish")
            record_data1 = []


        if len(record_data2) > 0 and not is_recording:
            
            ## create file if it doesn't exist or 
            ## append data to the file if it exists
            try:
                with open(DATA_COLLECTION_FOLDER + thing_name+'device2' + "/" + user_name +'device2'+ "/" + activity_list[activity_index]+'device2'+'.json', "r") as file:
                    listObj = json.load(file)
            except:
                listObj = []
                print("new file")

            ### store the data into the list
            with open(DATA_COLLECTION_FOLDER+thing_name+'device2' + "/" + user_name +'device2'+ "/"+ activity_list[activity_index]+'device2'+'.json', "w+") as file:
                print(activity_list[activity_index])
                print(len(listObj))
                if overwrite and len(listObj) > 0:
                    listObj[-1] = {"background": background_fft_profile2.tolist(), "record_data":record_data2}
                    overwrite = False
                else:
                    listObj.append({"background": background_fft_profile2.tolist(), "record_data":record_data2})
                json.dump(listObj, file, allow_nan = True)
                print("Record Finish")
            record_data2 = []


        if len(record_data3) > 0 and not is_recording:
            
            ## create file if it doesn't exist or 
            ## append data to the file if it exists
            try:
                with open(DATA_COLLECTION_FOLDER + thing_name+'device3' + "/" + user_name +'device3'+ "/" + activity_list[activity_index]+'device3'+'.json', "r") as file:
                    listObj = json.load(file)
            except:
                listObj = []
                print("new file")

            ### store the data into the list
            with open(DATA_COLLECTION_FOLDER+thing_name+'device3' + "/" + user_name +'device3'+ "/"+ activity_list[activity_index]+'device3'+'.json', "w+") as file:
                print(activity_list[activity_index])
                print(len(listObj))
                if overwrite and len(listObj) > 0:
                    listObj[-1] = {"background": background_fft_profile3.tolist(), "record_data":record_data3}
                    overwrite = False
                else:
                    listObj.append({"background": background_fft_profile3.tolist(), "record_data":record_data3})
                json.dump(listObj, file, allow_nan = True)
                print("Record Finish")
            record_data3 = []


        if len(record_data4) > 0 and not is_recording:
            
            ## create file if it doesn't exist or 
            ## append data to the file if it exists
            try:
                with open(DATA_COLLECTION_FOLDER + thing_name+'device4' + "/" + user_name +'device4'+ "/" + activity_list[activity_index]+'device4'+'.json', "r") as file:
                    listObj = json.load(file)
            except:
                listObj = []
                print("new file")

            ### store the data into the list
            with open(DATA_COLLECTION_FOLDER+thing_name+'device4' + "/" + user_name +'device4'+ "/"+ activity_list[activity_index]+'device4'+'.json', "w+") as file:
                print(activity_list[activity_index])
                print(len(listObj))
                if overwrite and len(listObj) > 0:
                    listObj[-1] = {"background": background_fft_profile4.tolist(), "record_data":record_data4}
                    overwrite = False
                else:
                    listObj.append({"background": background_fft_profile4.tolist(), "record_data":record_data4})
                json.dump(listObj, file, allow_nan = True)
                print("Record Finish")
            record_data4 = []            
        

def demo(device, streaming_server):

    model_file = os.path.dirname(__file__)+ '/model/'+'cuttingboard_RF_model'
    loaded_model = joblib.load(model_file)

    windows = []
    POLL_SIZE = 20
    PREDICTION_WINDOW_SIZE = 24 

    poll = []

    background_fft_profile = device.calculate_background_fft_profile()

    while True:
        cmd = streaming_server.read_client_command()
        if cmd and cmd == 'Z':
            background_fft_profile = device.calculate_background_fft_profile()
            print("update background profile")

        data = device.sample().tolist()
        if len(data) > 0:
            streaming_server.streaming_signal_in_FFT(data, background_fft_profile)
            if data != None and len(data) > 0:
                windows.append(data)
            if len(windows) > PREDICTION_WINDOW_SIZE:
                windows.pop(0)
            if len(windows) >= PREDICTION_WINDOW_SIZE :
                signal, fft_windows = DSPUtils.segment_along_windows(windows, background_fft_profile, Device.BUFFER_SIZE, Device.SHIFT_SIZE)
                if not DSPUtils.is_noisy(signal, fft_windows):
                    prediction = loaded_model.predict([DSPUtils.extract_feature(signal, fft_windows)])
                    poll.append(prediction[0])
                else:
                    poll.append("Noisy")
            if len(poll) > POLL_SIZE:
                poll.pop(0)
            if len(poll) >= POLL_SIZE:
                max_occur = max(poll,key=poll.count)
                if poll.count(max_occur) >= POLL_SIZE/2:
                    data_string = "result,"+ max_occur + '\n'
                    streaming_server.enqueue(data_string)
                    print(max_occur)


def main():
    device = Device(Device.SAMPLE_DEVICE_ANALOG_DISCOVERY)
    device1 = Device1(Device1.SAMPLE_DEVICE_ANALOG_DISCOVERY)
    device2 = Device2(Device2.SAMPLE_DEVICE_ANALOG_DISCOVERY)
    device3 = Device3(Device3.SAMPLE_DEVICE_ANALOG_DISCOVERY)
    device4 = Device4(Device4.SAMPLE_DEVICE_ANALOG_DISCOVERY)

    print('start server')

    streaming_server = Server('0.0.0.0', 8080)
    streaming_server.start_server()
    time.sleep(1)
    try:
        server_use = input("Please enter what you are going to do? (0: data), (1:demo) :\n")
        if server_use == '0':
            collect_data(device, device1,device2,device3,device4, streaming_server)
            
        elif server_use == '1':
            demo(device, streaming_server) 
            #demo(device1, streaming_server)
            #demo(device2, streaming_server)
            #demo(device3, streaming_server)
            #demo(device4, streaming_server)           
    except KeyboardInterrupt:
        print("Caught KeyboardInterrupt, terminating server")

if __name__ == '__main__':
    main()
    # print(load_bitmasks())